<?php 

require ("../gestion/conectar.php");

class persona {
	public $id_rif_cedula;
	public $nombre;
	public $direccion;
	public $telefonos;
	public $email;
	public $contacto;
	public $zona_atencion;
	public $ciudad;
	public $contribuyente;
	 private $persona;

 public function consultarcliente (){
	  $consulta= "SELECT * FROM M_CLIENTE"; 
	  $valores= null;
	  
	  $oconexion= new conectorDB;
	   $this->persona=$oconexion-> consultaDB($consulta,$valores);
	   return $this-persona;
	   
		 }

}

class conectorDB extends configuracion{
	
	private $conexion;
	
	public function __construct(){
		
		
		$this->conexion = parent:: conectar();
		return $this-> conexion;
		
		
		
		}
	
	
	
	}



?>