<?php 

require ("../gestion/conectar.php");

class conectorDB extends configuracion{
	
	private $conexion;
	
	public function __construct(){
		
		
		$this->conexion = parent:: conectar();
		return $this-> conexion;
		
		
		
		}
	
	
	
	}


?>
