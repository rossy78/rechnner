<?php 
require("../gestion/conectar.php");

class cliente {
	public $id_rif_cedula;
	public $nombre;
	public $direccion;
	public $telefonos;
	public $email;
	public $contacto;
	public $zona_atencion;
	public $ciudad;
	public $contribuyente;
	
	public function consultaregistro ($id_rif_cedula,$nombre,$direccion,$telefonos,$email,$contacto,$zona_atencion,$ciudad,$contribuyente){
		
		$registrar= false;
		
		$consulta= "INSERT INTO M_CLIENTE (:id_cliente,:id_rif_cedula,:nombre,:direccion,:telefonos,:email,:contacto,:zona_atencion,:ciudad,:contribuyente)";
		
		
		
		}
	
	
	
	
	
	
	}



?>