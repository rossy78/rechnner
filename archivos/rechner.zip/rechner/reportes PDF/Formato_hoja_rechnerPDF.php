﻿<?php 
require ('fpdf.php');

class PDF extends fpdf {
	
	
} 
// DECLARACION DE LA HOJA

$pdf= new PDF ('P','mm','letter');
$pdf->AddPage();// NUEVA PAGINA
$pdf->Image('C:\Users\rossy\Documents\rechner\imagenes\logo_galac_informe.jpg','L',5,40,35); // INSERTAR IMAGEN
$pdf-> Setfont('Arial','B',20);// DEFINICION DE LETRAS NOMBRE DE LA EMPRESA
$pdf->SetTextColor(0,80,0);// DEFINICION DE COLOR VERDE 
$pdf->cell(135,15,'OFICINA  RECHNER.CA',0,1,'C');//  NOMBRE DE LA EMPRESA
$pdf->SetFont('Arial','',10); // DEFINICION DE LETRAS  PEQUEÑA
$pdf->Cell(175,0,'Aliado de Negocio Galac Software de los Altos Mirandinos y Valles del Tuy',0,2,'C');// SLOGAN
$pdf->Ln(2);
$pdf->Cell(200,5,'Contacto:0212-3643790/3640360/Oficinarechner@gmail.com/galac-rechner@hotmail.com',0,2,'C');// CONTACTO
$pdf->Ln(1);
$pdf->Cell(190,5,'Calle Paez, Paralela a la Av.Bolivar. 50 metros de Ipostel. Los Teques.Edo Miranda',0,1,'C');// DIRECCCION
$pdf->Ln(1); // SALTO DE LINEA
$pdf->Cell(0,0,'',1,1,'C');// DEFINICION DE LA LINEA DIVISORIA
$pdf->Ln();
$pdf-> Setfont('Arial','B',14);// DEFINICION DE 2DO TITULO
$pdf->SetTextColor(50); // DEFINICION DE COLOR DEL SEGUNDO TITULO
$pdf->cell(200,15,'REPORTE DE LLAMADAS POR CLIENTE',0,0,'C',0);// 2DO TITULO DE LA PAGINA
$pdf->Ln(3);


$pdf->OutPut();// CIEERE DEL OBJETO


?>
