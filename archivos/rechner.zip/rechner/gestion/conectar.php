<?php 

abstract class configuracion{
	protected $datahost;
	protected function conectar($archivo='configuracion.ini'){
		if (!$ajustes=parse_ini_file($archivo, true))throw new exeption ('No se pudo abrir el archivo'. archivo.'.');
		$controlador=$ajustes["database"]["driver"];
		$servidor=$ajustes["databese"]["host"];
		$basedato=$ajustes["database"]["base_dato"];
		$username=$ajustes["database"]["usuario"];
		$clave=$ajustes["database"]["password"];
		
	}
}
$cnn= new configuracion();
if($cnn->conectar()){
	
	 echo "conectado";
}
 else{
	 echo "desconectado";
	 
 }
	
	

		 try {
			 return $this->datahost= new PDO('sqlsrv:host=$servidor,base_dato=$basedato'.
			 $ajustes ['database']['usuario'],
			 $ajustes['database']['password'],
			 array (PDO::SQLSRV_ATTR_INIT_COMMAND => "SET_NAMES_UTF8"));
			
			 }
		 catch (PDOException $evento){
			 echo "ERROR, NO SE PUDO CONECTAR:".$evento-> getMessage();
			 } 
		  
		

?>