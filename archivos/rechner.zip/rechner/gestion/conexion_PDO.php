<?php 

$severname="localhost";
try
 {
$conexion_sqlsrv= new PDO("odbc:Driver={SQL Server};server=$severname;Database= rechner","sa",1234);
$conn-> setAttribute (PDO::ATTR_ERRMODE, PDO:: ERRMODE_EXCEPTION);
 }
catch (PDOException $evento){
			 echo "ERROR, NO SE PUDO CONECTAR:".$evento-> getMessage();
		 }
?>