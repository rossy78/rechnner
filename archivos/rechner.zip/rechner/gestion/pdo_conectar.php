<?php 
class conectar extends PDO{
	
	
	private $tipo_de_base= 'sqlsrv';
	private $host= 'localhost';
	private $servidor ='ROSSY-PC\SQLEXPRESS';
	private $base_dato ='rechner';
	private $usuario = 'sa';
	private $clave = '1234';
	private $conexion;
	
	private function _construct(){
		try{
			
			parent::_construct($this->tipo_de_base.':host='.$this->host. )catch (PDOExeption $e){
				echo 'HA SURGUIDO UN ERROR Y NO PUEDE COONECTARSE A LA BASE DE DATO'
				exit;
				}
			}
	}
	private function conectar_sqlsrv (){
		$this->conectar= mssql_pconnect($this->servidor, $this->usuario, $this->clave) or die (sqlsrv_errors ());	
		
		}
	private function seleccionar_bd(){
		
		$this-> mysql_select_db ($this->base_dato);
		
		}
	
	
	}




?>
